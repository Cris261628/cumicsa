"use client"

import { motion } from "framer-motion"
import {
  Shield,
  FileCheck,
  Award,
  Scale,
  CheckCircle,
  BookOpen,
} from "lucide-react"
import { AnimatedCrane } from "@/components/animated-crane"

const regulations = [
  {
    icon: Shield,
    title: "ISO 9001:2015",
    description: "Sistema de Gestión de Calidad certificado que garantiza procesos estandarizados y mejora continua.",
    color: "primary",
  },
  {
    icon: FileCheck,
    title: "ISO 14001:2015",
    description: "Gestión Ambiental responsable, minimizando el impacto ecológico en todos nuestros proyectos.",
    color: "secondary",
  },
  {
    icon: Award,
    title: "ISO 45001:2018",
    description: "Seguridad y Salud Ocupacional, protegiendo a nuestro equipo y colaboradores.",
    color: "primary",
  },
  {
    icon: Scale,
    title: "Normativa NOM",
    description: "Cumplimiento estricto de las Normas Oficiales Mexicanas en construcción.",
    color: "secondary",
  },
]

const certifications = [
  "Registro IMSS",
  "Registro INFONAVIT",
  "Padrón de Contratistas",
  "Licencia de Construcción",
  "Certificación Ambiental",
  "Seguro de Responsabilidad Civil",
]

export function Regulations() {
  return (
    <section id="normativas" className="py-24 bg-muted relative overflow-hidden">
      {/* Construction Elements Background */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
        <svg className="absolute top-10 left-10 w-32 h-32 text-primary/5" viewBox="0 0 100 100">
          <rect x="10" y="10" width="80" height="80" fill="currentColor" />
        </svg>
        <svg className="absolute bottom-20 right-20 w-40 h-40 text-secondary/5" viewBox="0 0 100 100">
          <polygon points="50,10 90,90 10,90" fill="currentColor" />
        </svg>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            <span className="text-secondary">Normativas</span> y Certificaciones
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-lg">
            Cumplimos con los más altos estándares de calidad, seguridad y
            responsabilidad ambiental
          </p>
        </motion.div>

        {/* Main Regulations */}
        <div className="grid md:grid-cols-2 gap-8 mb-16">
          {regulations.map((reg, index) => (
            <AnimatedCrane
              key={reg.title}
              direction={index % 2 === 0 ? "left" : "right"}
              delay={index * 0.1}
            >
              <motion.div
                whileHover={{ scale: 1.02 }}
                className="bg-card rounded-2xl p-8 shadow-lg border border-border flex gap-6"
              >
                <div
                  className={`w-16 h-16 rounded-xl flex-shrink-0 flex items-center justify-center ${
                    reg.color === "primary"
                      ? "bg-primary/10"
                      : "bg-secondary/10"
                  }`}
                >
                  <reg.icon
                    className={`w-8 h-8 ${
                      reg.color === "primary" ? "text-primary" : "text-secondary"
                    }`}
                  />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-foreground mb-2">
                    {reg.title}
                  </h3>
                  <p className="text-muted-foreground">{reg.description}</p>
                </div>
              </motion.div>
            </AnimatedCrane>
          ))}
        </div>

        {/* Certifications List */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-card rounded-2xl p-8 md:p-12 shadow-lg border border-border"
        >
          <div className="flex items-center gap-4 mb-8">
            <div className="w-14 h-14 rounded-xl bg-secondary/10 flex items-center justify-center">
              <BookOpen className="w-7 h-7 text-secondary" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-foreground">
                Registros y Permisos
              </h3>
              <p className="text-muted-foreground">
                Documentación vigente y actualizada
              </p>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
            {certifications.map((cert, index) => (
              <motion.div
                key={cert}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center gap-3 p-4 rounded-lg bg-muted"
              >
                <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                <span className="text-foreground font-medium">{cert}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Trust Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <div className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-primary/10 text-primary">
            <Shield className="w-5 h-5" />
            <span className="font-medium">
              100% en cumplimiento normativo en los últimos 10 años
            </span>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
