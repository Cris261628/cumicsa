"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ChevronDown } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export function Hero() {
  return (
    <section
      id="inicio"
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-secondary via-secondary/90 to-secondary/80">
        {/* Grid Pattern */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            backgroundSize: "50px 50px",
          }}
        />
        {/* Animated Construction Elements */}
        <motion.div
          className="absolute top-20 left-10 opacity-20"
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        >
          <svg width="100" height="100" viewBox="0 0 100 100" fill="none">
            <circle cx="50" cy="50" r="40" stroke="oklch(0.7 0.18 55)" strokeWidth="4" />
            <circle cx="50" cy="50" r="20" fill="oklch(0.7 0.18 55)" fillOpacity="0.3" />
          </svg>
        </motion.div>
        <motion.div
          className="absolute bottom-40 right-20 opacity-20"
          animate={{ y: [0, -20, 0] }}
          transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        >
          <svg width="80" height="80" viewBox="0 0 80 80" fill="none">
            <rect x="10" y="10" width="60" height="60" stroke="oklch(0.7 0.18 55)" strokeWidth="4" />
            <rect x="25" y="25" width="30" height="30" fill="oklch(0.7 0.18 55)" fillOpacity="0.3" />
          </svg>
        </motion.div>
      </div>

      {/* Animated Crane */}
      <div className="absolute top-0 right-0 w-96 h-96 pointer-events-none">
        <svg viewBox="0 0 400 400" className="w-full h-full">
          {/* Crane Tower */}
          <motion.g
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 1, delay: 0.5 }}
          >
            {/* Main Tower */}
            <rect x="340" y="50" width="30" height="350" fill="oklch(0.7 0.18 55)" />
            {/* Tower Cross Braces */}
            {[0, 1, 2, 3, 4, 5, 6].map((i) => (
              <g key={i}>
                <line
                  x1="340"
                  y1={70 + i * 50}
                  x2="370"
                  y2={100 + i * 50}
                  stroke="oklch(0.6 0.15 55)"
                  strokeWidth="3"
                />
                <line
                  x1="370"
                  y1={70 + i * 50}
                  x2="340"
                  y2={100 + i * 50}
                  stroke="oklch(0.6 0.15 55)"
                  strokeWidth="3"
                />
              </g>
            ))}
            {/* Horizontal Jib */}
            <rect x="100" y="45" width="270" height="15" fill="oklch(0.7 0.18 55)" />
            {/* Jib Support */}
            <line x1="355" y1="20" x2="150" y2="45" stroke="oklch(0.6 0.15 55)" strokeWidth="4" />
            <line x1="355" y1="20" x2="355" y2="45" stroke="oklch(0.6 0.15 55)" strokeWidth="4" />
            {/* Counter Weight */}
            <rect x="340" y="45" width="50" height="25" fill="oklch(0.5 0.1 55)" />
            {/* Cabin */}
            <rect x="330" y="55" width="40" height="35" fill="oklch(0.65 0.15 55)" rx="3" />
            <rect x="335" y="60" width="15" height="10" fill="oklch(0.8 0.1 260)" rx="1" />
          </motion.g>

          {/* Animated Cable and Hook */}
          <motion.g
            initial={{ y: -50 }}
            animate={{ y: [0, 30, 0] }}
            transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
          >
            <line x1="180" y1="60" x2="180" y2="200" stroke="oklch(0.4 0 0)" strokeWidth="3" />
            {/* Hook */}
            <path
              d="M170 200 L190 200 L190 220 Q190 235 180 235 Q170 235 170 220 Z"
              fill="oklch(0.7 0.18 55)"
            />
            {/* Lifting Block */}
            <motion.rect
              x="150"
              y="240"
              width="60"
              height="40"
              fill="oklch(0.45 0.2 260)"
              rx="3"
              animate={{ rotate: [0, 2, -2, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </motion.g>
        </svg>
      </div>

      {/* Content */}
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-6"
          >
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/logo%20-%20copia-b6zkgmEZuVa1sp0MQF2h4tTWE1uGh3.png"
              alt="CUMICSA Logo"
              width={120}
              height={120}
              className="mb-4"
            />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-6 text-balance"
          >
            Construyendo el{" "}
            <span className="text-primary">futuro</span> con excelencia
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-lg md:text-xl text-white/80 mb-8 max-w-2xl text-pretty"
          >
            Más de 20 años de experiencia en construcción, infraestructura y
            desarrollo de proyectos que transforman comunidades.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-wrap gap-4"
          >
            <Button
              asChild
              size="lg"
              className="bg-primary hover:bg-primary/90 text-primary-foreground text-lg px-8"
            >
              <Link href="#proyectos">Ver Proyectos</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-secondary text-lg px-8"
            >
              <Link href="#contacto">Contáctanos</Link>
            </Button>
          </motion.div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <Link href="#vision-mision" className="text-white/60 hover:text-white transition-colors">
          <ChevronDown size={32} />
        </Link>
      </motion.div>
    </section>
  )
}
